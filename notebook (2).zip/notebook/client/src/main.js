import { createApp } from 'vue'
import { createPinia } from 'pinia'

import App from './App.vue'
import router from './router'
import * as Vant from 'vant'

import 'vant/lib/index.css';
import './assets/style/reset.css'
import 'lib-flexible/flexible.js'



const app = createApp(App)

app
    .use(createPinia())
    .use(router)
    .use(Vant)

app.mount('#app')
