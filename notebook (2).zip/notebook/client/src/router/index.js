import { createRouter, createWebHistory } from 'vue-router'
import noteClass from '../views/noteClass.vue'
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: "home",
      redirect: '/noteClass'
    },
    {
      path: '/noteClass',
      name: 'noteClass',
      component: noteClass,
      meta: {
        title: '笔记分类'
      }
    },
    {
      path: '/notePublish',
      name: 'notePublish',
      component: () => import('../views/notePublish.vue'),
      meta: {
        title: "写笔记"
      }
    },
    {
      path: '/noteList',
      name: 'noteList',
      component: () => import('../views/noteList.vue'),
      meta: {
        title: '笔记'
      }
    },
    {
      path: '/noteDetail',
      name: 'noteDetail',
      component: () => import('../views/noteDetail.vue')
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('../views/Login.vue'),
      meta: {
        title: '登录'
      }
    },
    {
      path: '/register',
      name: 'register',
      component: () => import('../views/Register.vue'),
      meta: {
        title: '注册'
      }
    }
  ]
})

// 全局路由守卫
const whitePass = ['/login', '/register','/noteClass']
router.beforeEach((to, from, next) => {
  document.title = to.meta.title
  if (!whitePass.includes(to.path)) { // 需要校验
    // 判断浏览器本地有无userInfo
    if (!localStorage.getItem('userInfo')) { //没登录
      next('/login')
      return
    }
    next()
    return
  }
  next()
})

export default router
