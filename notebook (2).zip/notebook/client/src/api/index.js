import axios from "axios";
import { showToast } from "vant";

axios.defaults.baseURL = 'http://139.224.58.229:3000'
axios.defaults.headers.post['Content-Type'] = 'application/json'

// 请求拦截
axios.interceptors.request.use(req => {
    let jwtToken = localStorage.getItem('token')
    if (jwtToken) {
        req.headers.Authorization = jwtToken
    }
    return req
})


// 响应拦截
axios.interceptors.response.use(
    res => {
        if (res.status !== 200) { // 程序性错误
            showToast('服务器内部错误');
            return Promise.reject(res)
        } else {
            if (res.data.code !== '800') { // 逻辑错误
                showToast(res.data.message);
                return Promise.reject(res);
            } else {
                showToast(res.data.message)
                return res.data
            }
        }
    }
)

export default axios;