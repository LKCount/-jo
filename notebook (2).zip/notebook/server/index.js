const Koa = require('koa')
const cors = require('@koa/cors')
const { bodyParser } = require('@koa/bodyparser')
const useRouter = require('./router/index.js')


const app = new Koa()

app.use(cors()) // 允许跨域
app.use(bodyParser())
// 生效路由
useRouter(app)

app.listen(3000, () => {
  console.log('Server listening on port http://localhost:3000')
})